package com.cg.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cg.utilities.propRead;

public class pomshome {
	@FindBy(xpath="//*[@id=\"item_4_title_link\"]")
	private WebElement bagpack;	
	@FindBy(id="item_1_title_link")
	private WebElement tshirt;
	@FindBy(id="item_0_title_link")
	private WebElement blight;
	WebDriver driver;
	public pomshome(WebDriver driver) {
	PageFactory.initElements(driver,this);
		this.driver = driver;
	}
	public void bag()
	{
		bagpack.click();
	}
	
}
