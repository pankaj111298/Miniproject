package com.cg.pageobject;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;

import com.cg.utilities.ExcelReader;

public class pomcheck {
	@FindBy(id="first-name")
	private WebElement fname;
	@FindBy(id="last-name")
	private WebElement lname;
	@FindBy(id="postal-code")
	private WebElement post;
	
	WebDriver driver;

	public pomcheck(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@DataProvider
	public Object[][] getData() throws IOException
	{
		String filename="UserDetails.xlsx";
		String filepath=System.getProperty("user.dir")+"/src/com/cg/testdata";
		String sheetname="UserDetails";
		//ExcelReader.ReadExeclData(filepath, filename, sheetname);
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);	

		
	}
	
	

}
