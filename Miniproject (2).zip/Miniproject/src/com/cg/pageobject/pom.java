package com.cg.pageobject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pom {
	
	@FindBy(id="user-name")
	private WebElement uname;
	
	@FindBy(id="password")
	private WebElement psswd;
	
	@FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/input[3]")
	private WebElement button;
	
	WebDriver driver;
	Document d;
	SAXReader sa;
	String stnd;

	public pom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void xml() throws FileNotFoundException, DocumentException{
		FileInputStream in = new FileInputStream(System.getProperty("user.dir")+ "/src/com/cg/testdata/ObjectRepository.xml");
		 sa=new SAXReader();
		d = sa.read(in);
		
		
	}
	
	public void standard()	
	{
		stnd=d.selectSingleNode("//CalorieDetails/standard").getText();
		uname.sendKeys(stnd);
	}
	public void problem()
	{
		uname.sendKeys("problem_user");
	}
	public void performance()
	{
		uname.sendKeys("performance_glitch_user");
	}
	public void psswd()
	{
		psswd.sendKeys("secret_sauce");
	}
	public void button()
	{
		button.click();
	}

}
