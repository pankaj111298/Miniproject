package com.cg.pageobject;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;

public class pomcheck {
	
	@FindBy(xpath="//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]")
	private WebElement cbutton;
	@FindBy(xpath="//*[@id=\"cart_contents_container\"]/div/div[2]/a[1]")
	private WebElement conshop;	
	@FindBy(id="first-name")
	private WebElement fname;
	@FindBy(id="last-name")
	private WebElement lname;
	@FindBy(id="postal-code")
	private WebElement post;
	@FindBy(xpath="//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")
	private WebElement conbutton;
	@FindBy(xpath="//*[@id=\"checkout_summary_container\"]/div/div[2]/div[8]/a[2]")
	private WebElement finish;
	@FindBy(xpath="//*[@id=\"menu_button_container\"]/div/div[3]/div/button")
	private WebElement mbutton;
	@FindBy(xpath="//*[@id=\"menu_button_container\"]/div/div[2]/div[1]")
	private WebElement  div;
	@FindBy(xpath="//*[@id=\"menu_button_container\"]/div/div[2]/div[1]/nav")
	private WebElement nav;
	@FindBy(xpath="//*[@id=\"logout_sidebar_link\"]")
	private WebElement logout;
	@FindBy(xpath="//*[@id=\"inventory_sidebar_link\"]")
	private WebElement allitems;
	@FindBy(xpath="//*[@id=\"reset_sidebar_link\"]")
	private WebElement reset;
	@FindBy(xpath="//*[@id=\"menu_button_container\"]/div/div[2]/div[2]/div/button")
	private WebElement cancel;
	WebDriver driver;

	Actions a;
	public pomcheck(WebDriver driver) {
		this.driver = driver;
		a=new Actions(driver);
		PageFactory.initElements(driver, this);
	}
	public void checkout()
	{
		cbutton.click();
	}
	public void EnterDetails(String first,String last,String code)
	{
		fname.sendKeys(first);
		lname.sendKeys(last);
		post.sendKeys(code);
		
	}
	public void conti()
	{
		conbutton.click();
		
	}
	public void shop()
	{
		conshop.click();
		
	}
	public void finishclick()
	{
		finish.click();
		
	}
	public void logout()
	{
			mbutton.click();
			a.moveToElement(logout).moveByOffset(-112 ,336).click().perform();
			logout.click();
	}
	public void allitems()
	{
			mbutton.click();
			a.moveToElement(allitems).moveByOffset(-12,53).click().perform();
			allitems.click();
	}
	public void reset()
	{
		mbutton.click();
		a.moveToElement(reset).moveByOffset(-112,336).click().perform();
		reset.click();

	}
	

}
