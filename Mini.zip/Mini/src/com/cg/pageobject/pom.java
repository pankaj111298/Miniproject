package com.cg.pageobject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pom {
	
	@FindBy(id="user-name")
	private WebElement uname;
	
	@FindBy(id="password")
	private WebElement psswd;
	
	@FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/input[3]")
	private WebElement button;
	
	WebDriver driver;
	Document d;
	SAXReader sa;
	String stnd;
	String prblm;
	String perform;
	String lock;

	public pom(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void xml() throws FileNotFoundException, DocumentException{
		FileInputStream in = new FileInputStream(System.getProperty("user.dir")+ "/src/com/cg/testdata/Caloriexml.xml");
		 sa=new SAXReader();
		d = sa.read(in);
		
		
	}
	
	public void standard() throws FileNotFoundException, DocumentException 
	{
		xml();
		stnd=d.selectSingleNode("//CalorieDetails/standard").getText();
		uname.sendKeys(stnd);
	}
	public void problem() throws FileNotFoundException, DocumentException
	{
		xml();
		prblm=d.selectSingleNode("//CalorieDetails/problem").getText();
		uname.sendKeys(prblm);
	}
	public void performance() throws FileNotFoundException, DocumentException
	{
		xml();
		perform=d.selectSingleNode("//CalorieDetails/performance").getText();
		uname.sendKeys(perform);
		
	}
	public void locked() throws FileNotFoundException, DocumentException
	{
		xml();
		lock=d.selectSingleNode("//CalorieDetails/locked").getText();
		uname.sendKeys(lock);
	}
	public void psswd()
	{
		psswd.sendKeys("secret_sauce");
	}
	public void button()
	{
		button.click();
	}

}
