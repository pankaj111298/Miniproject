package com.cg.pageobject;

import org.openqa.selenium.support.ui.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

public class pomshome {
	@FindBy(xpath="//*[@id=\"item_4_title_link\"]")
	private WebElement bagpack;	
	@FindBy(id="item_1_title_link")
	private WebElement tshirt;
	@FindBy(id="item_0_title_link")
	private WebElement blight;
	@FindBy(xpath="//*[@id=\"inventory_item_container\"]/div/div/div/button")
	private WebElement addbag;
	@FindBy(xpath="//*[@id=\"shopping_cart_container\"]/a")
	private WebElement cart;
	@FindBy(xpath="//*[@id=\"inventory_item_container\"]/div/div/div/div[1]")
	private WebElement extitle;
	@FindBy(xpath="/html/body/footer/ul/li[1]")
	private WebElement twitter;
	@FindBy(xpath="//*[@id=\"inventory_filter_container\"]/select")
	private WebElement dropdown;
	@FindBy(xpath="//*[@id=\"item_2_title_link\"]")
	private WebElement onesie;
	SoftAssert sa=new SoftAssert();
	WebDriver driver;
	public pomshome(WebDriver driver) {
	PageFactory.initElements(driver,this);
		this.driver = driver;
	}
	public void bag()
	{
		bagpack.click();
		String actual="Sauce Labs Backpack";
		String expected=extitle.getText();
		sa.assertEquals(actual, expected);
		addbag.click();	
		
	}
	public void carticon()
	{
		cart.click();
	}
	public void foot()
	{
		twitter.click();
	}
	public void blight()
	{
		blight.click();
		String actual="Sauce Labs Bike Light";
		String expected=extitle.getText();
		sa.assertEquals(actual, expected);
		addbag.click();	
		
	}
	public void drop()
	{
		Select sel=new Select(dropdown);
		sel.selectByIndex(2);
	}
	public void onn()
	{
		onesie.click();
		String actual="Sauce Labs Onesie";
		String expected=extitle.getText();
		sa.assertEquals(actual, expected);
		addbag.click();
		
	}
	
	
}
