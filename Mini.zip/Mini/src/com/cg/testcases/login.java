package com.cg.testcases;

import static org.testng.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Hashtable;

import org.dom4j.DocumentException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.cg.pageobject.pom;
import com.cg.pageobject.pomcheck;
import com.cg.pageobject.pomshome;
import com.cg.utilities.ExcelReader;
import com.cg.utilities.propRead;

public class login {

	WebDriver driver;
	pom p;
	pomshome s;
	pomcheck c;
	DesiredCapabilities d;
	
	
	@BeforeMethod
	public void browser() throws IOException {
		
		d=DesiredCapabilities.chrome();
		driver=new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), d);
		driver.get(propRead.getprop("url"));
		p=new pom(driver);
		s=new pomshome(driver);
		c=new pomcheck(driver);
	}
	@Test(dataProvider="getData")
	public void standarduser(Hashtable<String,String> h) throws IOException, DocumentException, InterruptedException {
		p.standard();
		p.psswd();
		p.button();
		s.bag();
		s.carticon();
		c.shop();
		Thread.sleep(2000);
		s.blight();
		s.carticon();
		c.checkout();		
		c.EnterDetails(h.get("Firstname"),h.get("Lastname"),h.get("Postalcode"));
		c.allitems();
		s.drop();
		s.onn();
		s.carticon();
		c.checkout();		
		c.EnterDetails(h.get("Firstname"),h.get("Lastname"),h.get("Postalcode"));
		c.conti();
		c.finishclick();
		Thread.sleep(2000);
		c.logout();
	}
	@Test(dataProvider="getpData")
	public void problemuser(Hashtable<String,String> h) throws IOException, DocumentException
	{
		p.problem();
		p.psswd();
		p.button();
		s.bag();
		s.carticon();
		c.checkout();
		c.EnterDetails(h.get("Firstname"),h.get("Lastname"),h.get("Postalcode"));
		c.reset();
		c.conti();
		c.finishclick();
		c.logout();
	}
	@Test(dataProvider="getperformData")
	public void performanceuser(Hashtable<String,String> h) throws FileNotFoundException, DocumentException
	{
		p.performance();
		p.psswd();
		p.button();
		s.bag();
		s.carticon();
		c.checkout();		
		c.EnterDetails(h.get("Firstname"),h.get("Lastname"),h.get("Postalcode"));
		c.conti();
		c.finishclick();
		c.logout();
	}
	@Test()
	public void lockuser() throws FileNotFoundException, DocumentException
	{
		p.locked();
		p.psswd();
		p.button();
		String actual="Epic sadface: Sorry, this user has been locked out.";
		String expected=driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/h3")).getText();
		assertEquals(actual, expected);
		
		
	}
	
	@DataProvider
	public Object[][] getData() throws IOException
	{
		
		String filename="Details.xlsx";
		String filepath=System.getProperty("user.dir")+"/src/com/cg/testdata";
		String sheetname="Details";
		//ExcelReader.ReadExeclData(filepath, filename, sheetname);
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);	

		
	}
	@DataProvider
	public Object[][] getpData() throws IOException
	{
		
		String filename="Details.xlsx";
		String filepath=System.getProperty("user.dir")+"/src/com/cg/testdata";
		String sheetname="pdetails";
		//ExcelReader.ReadExeclData(filepath, filename, sheetname);
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);	

		
	}
	@DataProvider
	public Object[][] getperformData() throws IOException
	{
		
		String filename="Details.xlsx";
		String filepath=System.getProperty("user.dir")+"/src/com/cg/testdata";
		String sheetname="perdetails";
		//ExcelReader.ReadExeclData(filepath, filename, sheetname);
		return ExcelReader.ReadExeclDataToObject(filepath, filename, sheetname);	

		
	}


	
}
